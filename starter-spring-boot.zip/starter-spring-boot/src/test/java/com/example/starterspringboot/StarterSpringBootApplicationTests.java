package com.example.starterspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StarterSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
