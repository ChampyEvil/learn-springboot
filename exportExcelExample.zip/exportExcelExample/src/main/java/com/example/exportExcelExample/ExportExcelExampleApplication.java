package com.example.exportExcelExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExportExcelExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExportExcelExampleApplication.class, args);
	}

}
